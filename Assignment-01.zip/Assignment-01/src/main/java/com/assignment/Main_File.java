package com.assignment;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.commons.lang3.math.NumberUtils;

public class Main_File {

	public static void main(String[] args) throws IOException {

		 Path fileName = Path.of("C:\\Users\\sgiradkar\\Documents\\New folder\\file1.txt");
		 
		 String str = Files.readString(fileName); //Reading data inside file
		 
		 System.out.println(str);
		
		if(NumberUtils.isNumber(str)) {  //Check Numeric or not
			System.out.println("String is numeric!");
			
			//Logic to check palindrome
			int r,sum=0,temp;     
		    int n = Integer.parseInt(str); //Converting it to Integer.
			  temp=n;    
			  while(n>0){    
			   r=n%10;  //getting remainder  
			   sum=(sum*10)+r;    
			   n=n/10;    
			  }    
			  
			  if(temp==sum) {
			   System.out.println("palindrome number");
			   //If palindrome add number inside the Excel sheet
			   		//Create blank workbook
			   		XSSFWorkbook workbook = new XSSFWorkbook();
			   		//Create a blank sheet
			   		XSSFSheet sheet = workbook.createSheet("Palindrome");
		         
			   		//String str = "hello";
			   		int num = Integer.parseInt(str);
		        
			   		//Create row object
			   		XSSFRow row;
		        
			   		row = sheet.createRow(0);
			   		Cell cell = row.createCell(0);
			   		cell.setCellValue("Palindrome:");
			   		
			   		cell = row.createCell(1);
			   		cell.setCellValue(str);
		   
			   		try (FileOutputStream outputStream = new FileOutputStream("C:\\Users\\sgiradkar\\Documents\\New folder\\Excel5.xlsx")) {
			   			workbook.write(outputStream);
			   		}
		        
			  }
			  else    
			   System.out.println("not palindrome");    
			
			
		//If data inside file is String (Non-numeric)
		} else {
			System.out.println("String is not numeric.");
			System.out.println("Lenghth of String is:"+ str.length());
		   //Adding file size in Excel sheet
			//Create blank workbook
	   		XSSFWorkbook workbook = new XSSFWorkbook();
	   		//Create a blank sheet
	   		XSSFSheet sheet = workbook.createSheet("String_Size");
         
	   		//String str = "hello";
	   		int size = str.length();
        
	   		//Create row object
	   		XSSFRow row;
        
	   		row = sheet.createRow(0);
	   		Cell cell = row.createCell(0);
	   		cell.setCellValue("String size:");
	   		
	   		cell = row.createCell(1);
	   		cell.setCellValue(size);
   
	   		try (FileOutputStream outputStream = new FileOutputStream("C:\\Users\\sgiradkar\\Documents\\New folder\\Excel5.xlsx")) {
	   			workbook.write(outputStream);
	   		}
		}
		
	}

}



import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.commons.lang3.math.NumberUtils;

public class Main_File2 {

	public static void main(String[] args) throws IOException {

		 Path fileName = Path.of("C:\\Users\\sgiradkar\\Documents\\New folder\\file1.txt");
		 
		 String str = Files.readString(fileName);
		 
		 System.out.println(str);
		 
		// if(isNumeric(str)) { 
		 
		// NumberUtils.isNumber(str)
		 
		//if (NumberUtils.isParsable(str)) {
			if(NumberUtils.isNumber(str)) {
			System.out.println("String is numeric!");
			
			
			int r,sum=0,temp;    
			  //int n=454;//It is the number variable to be checked for palindrome  
			 int n = Integer.parseInt(str);
			  temp=n;    
			  while(n>0){    
			   r=n%10;  //getting remainder  
			   sum=(sum*10)+r;    
			   n=n/10;    
			  }    
			  if(temp==sum) {
			   System.out.println("palindrome number");
			 //Create blank workbook
		        XSSFWorkbook workbook = new XSSFWorkbook();
				//Create a blank sheet
		        XSSFSheet sheet = workbook.createSheet("Java Books");
		         
		        //String str = "hello";
		        int num = Integer.parseInt(str);
		        
		      //Create row object
		        XSSFRow row;
		        
		        row = sheet.createRow(0);
		        Cell cell = row.createCell(0);
		        cell.setCellValue(str);
		   
		        try (FileOutputStream outputStream = new FileOutputStream("C:\\Users\\sgiradkar\\Documents\\New folder\\Excel5.xlsx")) {
		            workbook.write(outputStream);
		        }
		        
			  }
			  else    
			   System.out.println("not palindrome");    
			
			
			// Do something
		} else {
			System.out.println("String is not numeric.");
			System.out.println("Lenghth of String is:"+ str.length());
			
		}
		
	}

}

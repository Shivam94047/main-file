

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class c2 {

	public static void main(String[] args) throws IOException {
		//Create blank workbook
        XSSFWorkbook workbook = new XSSFWorkbook();
		//Create a blank sheet
        XSSFSheet sheet = workbook.createSheet("Java Books");
         
        String str = "hello";
        
      //Create row object
        XSSFRow row;
        
        row = sheet.createRow(0);
        Cell cell = row.createCell(0);
        cell.setCellValue(str);
   
        try (FileOutputStream outputStream = new FileOutputStream("C:\\Users\\sgiradkar\\Documents\\New folder\\Excel3.xlsx")) {
            workbook.write(outputStream);
        }
    }

}
